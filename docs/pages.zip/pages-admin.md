# صفحات تطبيق الإدارة (Admin SPA Pages)

**لغة الموقع الأساسية:** العربية السعودية مع دعم RTL - Arabic Saudi dialect with RTL support

يربط هذا المستند صفحات الإدارة بدوال عرض الطرق الدقيقة ويوفر ملاحظات التنفيذ للمطورين.

الملف: `frontend/admin/app.js`

---

## 1. نظرة عامة (Overview)

**الغرض:** لوحة تحكم شاملة مع مؤشرات الأداء الرئيسية وأشرطة تقدم SLA.

- **المسار:** `#/overview`
- **المعالج:** `renderOverview`
- **دعم RTL:** بطاقات ومؤشرات محاذاة لليمين

### المكونات والأحداث:
- **بطاقات المؤشرات:**
  - إجمالي المستخدمين المسجلين: `state.platform.totalUsers`
  - البائعين النشطين: `state.sellers.activeCount`
  - معدل النمو الشهري: `state.analytics.monthlyGrowth`
  - معدل رضا العملاء: `state.support.satisfactionRate`
- **أشرطة تقدم SLA:**
  - وقت الاستجابة للدعم: أقل من 2 ساعة
  - وقت حل التذاكر: أقل من 24 ساعة
  - معدل توفر النظام: 99.9%
  - معدل موافقة البائعين: خلال 48 ساعة
- **الإجراءات السريعة:**
  - مراجعة طلبات البائعين: `onClick` → `navigate("#/creators")`
  - المحتوى المعلق: `onClick` → `navigate("#/moderation")`
  - التذاكر المفتوحة: `onClick` → `navigate("#/support")`

### مفاتيح الترجمة:
```javascript
overview: "نظرة عامة",
platform_metrics: "مؤشرات المنصة",
total_users: "إجمالي المستخدمين",
active_sellers: "البائعين النشطين",
monthly_growth: "النمو الشهري",
satisfaction_rate: "معدل الرضا",
sla_metrics: "مؤشرات SLA",
support_response_time: "وقت الاستجابة للدعم",
ticket_resolution_time: "وقت حل التذاكر",
system_uptime: "معدل توفر النظام",
seller_approval_time: "وقت موافقة البائعين",
quick_actions: "إجراءات سريعة",
pending_sellers: "البائعين المعلقين",
pending_content: "المحتوى المعلق",
open_tickets: "التذاكر المفتوحة",
within_target: "ضمن الهدف",
above_target: "فوق الهدف",
below_target: "تحت الهدف"
```

### شرائح الحالة:
- `state.platform.metrics` (object)
- `state.sla.targets` (object)
- `state.sla.current` (object)
- `state.dashboard.alerts` (array)

### معايير القبول:
- تحميل المؤشرات في ≤ 1 ثانية
- أشرطة تقدم SLA تعكس الحالة الفعلية
- تحديث المؤشرات كل دقيقة
- RTL صحيح للأرقام والنسب المئوية

---

## 2. إدارة المبدعين (Creators Management)

**الغرض:** إدارة طلبات وحسابات المبدعين مع تبويبات التطبيقات والنشطين.

- **المسار:** `#/creators`
- **المعالج:** `renderCreators`
- **دعم RTL:** تبويبات وجداول محاذاة لليمين

### المكونات والأحداث:
- **تبويب طلبات التقديم:**
  - قائمة المتقدمين الجدد للحصول على حساب بائع
  - معلومات الملف الشخصي: الاسم، البريد، نوع المحتوى المقترح
  - مستندات التحقق: بطاقة الهوية، السجل التجاري
  - إجراءات: موافقة، رفض، طلب معلومات إضافية
- **تبويب البائعين النشطين:**
  - قائمة البائعين المعتمدين والنشطين
  - إحصائيات الأداء: المبيعات، التقييمات، المتابعين
  - إجراءات الإدارة: تعليق، تحذير، ترقية الحساب
- **مرشحات وبحث:**
  - بحث بالاسم أو البريد
  - تصفية بحالة التطبيق: جديد، قيد المراجعة، معتمد، مرفوض
  - تصفية بنوع المحتوى: أزياء، إلكترونيات، منزل وحديقة

### مفاتيح الترجمة:
```javascript
creators_management: "إدارة المبدعين",
creators: "المبدعين",
applications: "طلبات التقديم",
active_creators: "المبدعين النشطين",
applicant_info: "معلومات المتقدم",
content_type: "نوع المحتوى",
verification_docs: "مستندات التحقق",
identity_card: "بطاقة الهوية",
business_registration: "السجل التجاري",
approve_application: "موافقة على الطلب",
reject_application: "رفض الطلب",
request_more_info: "طلب معلومات إضافية",
creator_performance: "أداء المبدع",
sales_volume: "حجم المبيعات",
rating_score: "نقاط التقييم",
followers_count: "عدد المتابعين",
suspend_account: "تعليق الحساب",
send_warning: "إرسال تحذير",
upgrade_account: "ترقية الحساب",
application_status: "حالة الطلب",
new: "جديد",
under_review: "قيد المراجعة",
approved: "معتمد",
rejected: "مرفوض"
```

### شرائح الحالة:
- `state.creators.applications` (array)
- `state.creators.active` (array)
- `state.creators.filters` (object)
- `state.creators.selectedTab` (string)

### معايير القبول:
- تحميل التطبيقات والبائعين النشطين بسرعة
- مراجعة سهلة للمستندات والملفات الشخصية
- إجراءات الموافقة/الرفض مع إشعارات فورية
- RTL صحيح للتبويبات والجداول

---

## 3. التجارة المباشرة (Live Commerce)

**الغرض:** إدارة جلسات البث المباشر مع تبويبات النشطة/المجدولة/السجل.

- **المسار:** `#/live`
- **المعالج:** `renderLiveCommerce`
- **دعم RTL:** تبويبات وعناصر تحكم محاذاة لليمين

### المكونات والأحداث:
- **تبويب الجلسات النشطة:**
  - قائمة البث المباشر الجاري حالياً
  - معلومات البث: البائع، عنوان البث، عدد المشاهدين، المبيعات
  - إجراءات الإشراف: مراقبة، تحذير، إيقاف البث
- **تبويب الجلسات المجدولة:**
  - جلسات البث المخطط لها مستقبلياً
  - تفاصيل الجدولة: التاريخ، الوقت، المنتجات المميزة
  - إجراءات: موافقة، تعديل الجدولة، إلغاء
- **تبويب سجل البث:**
  - جميع الجلسات السابقة مع الإحصائيات
  - أداء البث: المشاهدات، التفاعل، المبيعات المحققة
  - تقييم جودة المحتوى

### مفاتيح الترجمة:
```javascript
live_commerce: "التجارة المباشرة",
live_sessions: "جلسات البث المباشر",
active_sessions: "الجلسات النشطة",
scheduled_sessions: "الجلسات المجدولة",
session_history: "سجل الجلسات",
live_stream_info: "معلومات البث المباشر",
stream_title: "عنوان البث",
viewers_count: "عدد المشاهدين",
live_sales: "المبيعات المباشرة",
moderation_actions: "إجراءات الإشراف",
monitor_stream: "مراقبة البث",
send_warning: "إرسال تحذير",
stop_stream: "إيقاف البث",
scheduling_details: "تفاصيل الجدولة",
stream_date: "تاريخ البث",
stream_time: "وقت البث",
featured_products: "المنتجات المميزة",
approve_schedule: "موافقة على الجدولة",
edit_schedule: "تعديل الجدولة",
cancel_stream: "إلغاء البث",
stream_performance: "أداء البث",
total_views: "إجمالي المشاهدات",
engagement_rate: "معدل التفاعل",
sales_generated: "المبيعات المحققة",
content_quality: "جودة المحتوى"
```

### شرائح الحالة:
- `state.liveCommerce.activeSessions` (array)
- `state.liveCommerce.scheduledSessions` (array)
- `state.liveCommerce.sessionHistory` (array)
- `state.liveCommerce.selectedTab` (string)

### معايير القبول:
- مراقبة الجلسات النشطة في الوقت الفعلي
- إدارة فعالة للجلسات المجدولة
- سجل شامل مع إحصائيات مفيدة
- RTL صحيح للتبويبات والبيانات

---

## 4. إشراف المحتوى (Moderation)

**الغرض:** مراجعة المحتوى والبائعين مع قوائم انتظار منفصلة.

- **المسار:** `#/moderation`
- **المعالج:** `renderModeration`
- **دعم RTL:** قوائم وأدوات مراجعة محاذاة لليمين

### المكونات والأحداث:
- **قائمة انتظار المحتوى:**
  - منشورات البائعين الجديدة في انتظار الموافقة
  - مراجعات المنتجات المبلغ عنها
  - صور وفيديوهات المستخدمين
  - إجراءات: موافقة، رفض، طلب تعديل
- **قائمة انتظار البائعين:**
  - طلبات تسجيل البائعين الجدد
  - تحديثات ملفات البائعين الحالية
  - مراجعة المستندات والتحقق من الهوية
- **أدوات المراجعة:**
  - معاينة المحتوى بحجم كامل
  - سجل المراجعات السابقة للمستخدم
  - أسباب الرفض المعيارية
  - إشعارات فورية للمستخدمين

### مفاتيح الترجمة:
```javascript
content_moderation: "إشراف المحتوى",
moderation: "الإشراف",
content_queue: "قائمة انتظار المحتوى",
sellers_queue: "قائمة انتظار البائعين",
pending_posts: "المنشورات المعلقة",
reported_reviews: "المراجعات المبلغ عنها",
user_media: "وسائط المستخدمين",
seller_applications: "طلبات البائعين",
profile_updates: "تحديثات الملفات الشخصية",
document_verification: "التحقق من المستندات",
review_tools: "أدوات المراجعة",
content_preview: "معاينة المحتوى",
review_history: "سجل المراجعات",
rejection_reasons: "أسباب الرفض",
inappropriate_content: "محتوى غير مناسب",
spam_content: "محتوى مزعج",
copyright_violation: "انتهاك حقوق الطبع",
approve_content: "موافقة على المحتوى",
reject_content: "رفض المحتوى",
request_modification: "طلب تعديل",
instant_notifications: "إشعارات فورية"
```

### شرائح الحالة:
- `state.moderation.contentQueue` (array)
- `state.moderation.sellersQueue` (array)
- `state.moderation.currentReview` (object)
- `state.moderation.rejectionReasons` (array)

### معايير القبول:
- قوائم انتظار محدثة في الوقت الفعلي
- مراجعة سريعة وفعالة للمحتوى
- إشعارات فورية للمستخدمين بقرارات المراجعة
- RTL صحيح لجميع أدوات المراجعة

---

## 5. إدارة الطلبات (Orders Management)

**الغرض:** بحث وتصفية الطلبات مع إجراءات تحديث الحالة.

- **المسار:** `#/orders`
- **المعالج:** `renderOrders`
- **دعم RTL:** جدول وأدوات بحث محاذاة لليمين

### المكونات والأحداث:
- **جدول الطلبات الشامل:**
  - أعمدة: رقم الطلب، العميل، البائع، التاريخ، الحالة، المجموع
  - حالات الطلب: جديد، مؤكد، قيد التحضير، مشحون، مستلم، ملغي
  - ألوان مميزة لكل حالة لسهولة التمييز
- **أدوات البحث المتقدم:**
  - بحث برقم الطلب: `onInput` → `searchByOrderNumber()`
  - بحث باسم العميل: `onInput` → `searchByCustomer()`
  - بحث باسم البائع: `onInput` → `searchBySeller()`
- **مرشحات متعددة:**
  - تصفية بالحالة: dropdown مع خيارات متعددة
  - تصفية بالتاريخ: date range picker
  - تصفية بالمبلغ: range slider
- **إجراءات الحالة:**
  - تحديث حالة فردية: dropdown → `updateOrderStatus(orderId, status)`
  - تحديث مجموعي: checkbox selection → `bulkUpdateStatus()`
  - إضافة ملاحظات: modal → `addOrderNote()`

### مفاتيح الترجمة:
```javascript
orders_management: "إدارة الطلبات",
orders: "الطلبات",
order_number: "رقم الطلب",
customer: "العميل",
seller: "البائع",
order_date: "تاريخ الطلب",
status: "الحالة",
total_amount: "إجمالي المبلغ",
new_order: "طلب جديد",
confirmed: "مؤكد",
preparing: "قيد التحضير",
shipped: "مشحون",
delivered: "مستلم",
cancelled: "ملغي",
search_by_order: "بحث برقم الطلب",
search_by_customer: "بحث بالعميل",
search_by_seller: "بحث بالبائع",
filter_by_status: "تصفية بالحالة",
filter_by_date: "تصفية بالتاريخ",
filter_by_amount: "تصفية بالمبلغ",
update_status: "تحديث الحالة",
bulk_update: "تحديث مجموعي",
add_note: "إضافة ملاحظة",
order_notes: "ملاحظات الطلب"
```

### شرائح الحالة:
- `state.orders.list` (array)
- `state.orders.filters` (object)
- `state.orders.searchQuery` (string)
- `state.orders.selectedOrders` (array)

### معايير القبول:
- تحميل الطلبات بسرعة مع pagination
- بحث فوري أثناء الكتابة
- تصفية متعددة تعمل معاً
- تحديث الحالة فوري مع إشعارات
- RTL صحيح للجدول والمرشحات

---

## 6. الدعم الفني (Support)

**الغرض:** إدارة التذاكر مع عرض الخيوط وتعيين المسؤولين.

- **المسار:** `#/support`
- **المعالج:** `renderSupport`
- **دعم RTL:** تذاكر ومحادثات محاذاة لليمين

### المكونات والأحداث:
- **قائمة التذاكر:**
  - جدول التذاكر مع الأولوية والحالة
  - أعمدة: ID، العنوان، المستخدم، الأولوية، الحالة، تاريخ الإنشاء
  - ألوان الأولوية: أحمر (عالية)، أصفر (متوسطة)، أخضر (منخفضة)
- **عرض خيط المحادثة:**
  - سجل المحادثة الكامل بين المستخدم والدعم
  - رسائل مرتبة زمنياً مع طوابع زمنية
  - إرفاق ملفات وصور في الردود
- **تعيين المسؤولين:**
  - قائمة فريق الدعم المتاح
  - تعيين تذكرة لمختص معين
  - إعادة تعيين أو نقل التذاكر
- **إجراءات التذكرة:**
  - تغيير الأولوية: dropdown → `updateTicketPriority()`
  - تحديث الحالة: مفتوحة، قيد العمل، محلولة، مغلقة
  - إضافة رد: rich text editor → `addTicketReply()`

### مفاتيح الترجمة:
```javascript
support: "الدعم الفني",
support_tickets: "تذاكر الدعم",
ticket_id: "معرف التذكرة",
ticket_title: "عنوان التذكرة",
user: "المستخدم",
priority: "الأولوية",
ticket_status: "حالة التذكرة",
creation_date: "تاريخ الإنشاء",
high_priority: "أولوية عالية",
medium_priority: "أولوية متوسطة",
low_priority: "أولوية منخفضة",
thread_view: "عرض الخيط",
conversation_history: "سجل المحادثة",
attach_files: "إرفاق ملفات",
assign_to: "تعيين إلى",
support_team: "فريق الدعم",
reassign_ticket: "إعادة تعيين التذكرة",
transfer_ticket: "نقل التذكرة",
open: "مفتوحة",
in_progress: "قيد العمل",
resolved: "محلولة",
closed: "مغلقة",
update_priority: "تحديث الأولوية",
update_status: "تحديث الحالة",
add_reply: "إضافة رد",
ticket_actions: "إجراءات التذكرة"
```

### شرائح الحالة:
- `state.support.tickets` (array)
- `state.support.currentTicket` (object)
- `state.support.conversation` (array)
- `state.support.team` (array)

### معايير القبول:
- قائمة التذاكر محدثة في الوقت الفعلي
- عرض خيط المحادثة سلس وسريع
- تعيين المسؤولين مع إشعارات فورية
- إرفاق الملفات يعمل بكفاءة
- RTL صحيح للمحادثات والردود

---

## 7. إعدادات المنصة (Platform Settings)

**الغرض:** تكوين الإعدادات العامة للمنصة والسياسات.

- **المسار:** `#/settings`
- **المعالج:** `renderSettings`
- **دعم RTL:** نماذج وتحكم محاذاة لليمين

### المكونات والأحداث:
- **الإعدادات العامة:**
  - اسم المنصة وشعارها: `state.platform.name`, `state.platform.logo`
  - معلومات الاتصال: البريد الإلكتروني، الهاتف، العنوان
  - اللغات المدعومة: العربية (افتراضي)، الإنجليزية
  - العملة الافتراضية: الريال السعودي (SAR)
- **سياسات المنصة:**
  - شروط الخدمة: rich text editor للتحرير
  - سياسة الخصوصية: محرر مع معاينة
  - قواعد المجتمع: إرشادات للمستخدمين والبائعين
- **إعدادات التجارة:**
  - معدلات العمولة: للبائعين والمبدعين
  - سياسات الإرجاع: مدد وشروط الإرجاع
  - طرق الدفع المدعومة: بطاقات، محافظ رقمية
- **إعدادات الإشعارات:**
  - قوالب البريد الإلكتروني: ترحيب، تأكيد طلب، شحن
  - إعدادات الرسائل النصية: OTP، تنبيهات
  - الإشعارات الفورية: إعدادات push notifications

### مفاتيح الترجمة:
```javascript
platform_settings: "إعدادات المنصة",
settings: "الإعدادات",
general_settings: "الإعدادات العامة",
platform_name: "اسم المنصة",
platform_logo: "شعار المنصة",
contact_info: "معلومات الاتصال",
email_address: "عنوان البريد الإلكتروني",
phone_number: "رقم الهاتف",
address: "العنوان",
supported_languages: "اللغات المدعومة",
default_currency: "العملة الافتراضية",
platform_policies: "سياسات المنصة",
terms_of_service: "شروط الخدمة",
privacy_policy: "سياسة الخصوصية",
community_guidelines: "قواعد المجتمع",
commerce_settings: "إعدادات التجارة",
commission_rates: "معدلات العمولة",
seller_commission: "عمولة البائع",
creator_commission: "عمولة المبدع",
return_policies: "سياسات الإرجاع",
return_period: "فترة الإرجاع",
supported_payments: "طرق الدفع المدعومة",
credit_cards: "البطاقات الائتمانية",
digital_wallets: "المحافظ الرقمية",
notification_settings: "إعدادات الإشعارات",
email_templates: "قوالب البريد الإلكتروني",
welcome_email: "بريد الترحيب",
order_confirmation: "تأكيد الطلب",
shipping_notification: "إشعار الشحن",
sms_settings: "إعدادات الرسائل النصية",
otp_messages: "رسائل OTP",
alert_messages: "رسائل التنبيه",
push_notifications: "الإشعارات الفورية"
```

### شرائح الحالة:
- `state.platform.settings` (object)
- `state.platform.policies` (object)
- `state.commerce.settings` (object)
- `state.notifications.templates` (array)

### معايير القبول:
- حفظ الإعدادات فوري مع تأكيد
- معاينة السياسات قبل النشر
- قوالب البريد قابلة للتخصيص بالكامل
- جميع الإعدادات تطبق فوراً على المنصة
- RTL صحيح لجميع النماذج والمحررات
