# صفحات تطبيق البائع (Seller SPA Pages)

**لغة الموقع الأساسية:** العربية السعودية مع دعم RTL - Arabic Saudi dialect with RTL support

يربط هذا المستند صفحات البائعين بدوال عرض الطرق الدقيقة ويوفر ملاحظات التنفيذ للمطورين.

الملف: `frontend/Seller/app.js`

---

## 1. لوحة التحكم (Dashboard)

**الغرض:** نظرة عامة على الأداء مع مؤشرات الأداء الرئيسية والإجراءات السريعة.

- **المسار:** `#/dashboard`
- **المعالج:** `renderDashboard`
- **دعم RTL:** بطاقات ومخططات محاذاة لليمين

### المكونات والأحداث:
- **بطاقات المؤشرات:**
  - إجمالي المبيعات: `state.analytics.totalSales`
  - الطلبات المعلقة: `state.orders.pending.length`
  - المنتجات المباشرة: `state.catalog.active.length`
  - معدل التحويل: `state.analytics.conversionRate`
- **مخططات KPI:**
  - مخطط خط المبيعات بالأيام: Chart.js integration
  - مخطط بار أفضل المنتجات: top 5 bestsellers
- **الإجراءات السريعة:**
  - زر "إضافة منتج": `onClick` → `navigate("#/catalog-new")`
  - زر "بث مباشر": `onClick` → `navigate("#/live")`

### مفاتيح الترجمة:
```javascript
dashboard: "لوحة التحكم",
total_sales: "إجمالي المبيعات",
pending_orders: "الطلبات المعلقة",
active_products: "المنتجات النشطة",
conversion_rate: "معدل التحويل",
sales_overview: "نظرة عامة على المبيعات",
top_products: "أفضل المنتجات",
quick_actions: "إجراءات سريعة",
add_product: "إضافة منتج",
start_live: "بدء بث مباشر",
this_week: "هذا الأسبوع",
this_month: "هذا الشهر"
```

### شرائح الحالة:
- `state.analytics.totalSales` (number)
- `state.analytics.conversionRate` (number)
- `state.orders.pending` (array)
- `state.catalog.products` (array)

### معايير القبول:
- تحميل المؤشرات في ≤ 1 ثانية مع البيانات المخزنة مؤقتاً
- المخططات تستجيب وقابلة للتفاعل
- الإجراءات السريعة تنتقل للصفحات الصحيحة
- RTL صحيح للأرقام والنصوص العربية

---

## 2. إدارة الكتالوج (Catalog Management)

**الغرض:** عرض وإدارة قائمة المنتجات مع إجراءات التحرير والحذف.

- **المسار:** `#/catalog`
- **المعالج:** `renderCatalog`
- **دعم RTL:** جدول وأزرار محاذاة لليمين

### المكونات والأحداث:
- **قائمة المنتجات:**
  - جدول بأعمدة: ID، الاسم، السعر، المخزون، الحالة، الإجراءات
  - زر تحرير: `onClick` → `navigate("#/catalog-edit/" + productId)`
  - زر حذف: `onClick` → `confirmDelete(productId)` → `actions.deleteProduct()`
- **مرشحات البحث:**
  - بحث بالاسم: `onInput` → `filterProducts(query)`
  - تصفية بالحالة: نشط، غير نشط، نفد المخزون
- **أزرار العمل:**
  - إضافة منتج جديد: `onClick` → `navigate("#/catalog-new")`
  - استيراد CSV: `onClick` → `navigate("#/catalog-import")`

### مفاتيح الترجمة:
```javascript
catalog: "الكتالوج",
products: "المنتجات",
product_name: "اسم المنتج",
price: "السعر",
stock: "المخزون",
status: "الحالة",
actions: "الإجراءات",
edit: "تحرير",
delete: "حذف",
active: "نشط",
inactive: "غير نشط",
out_of_stock: "نفد المخزون",
search_products: "بحث المنتجات",
add_new_product: "إضافة منتج جديد",
import_csv: "استيراد CSV",
confirm_delete: "تأكيد الحذف",
delete_product_confirm: "هل أنت متأكد من حذف هذا المنتج؟"
```

### شرائح الحالة:
- `state.catalog.products` (array)
- `state.catalog.filters` (object)
- `state.catalog.searchQuery` (string)

### معايير القبول:
- قائمة المنتجات تحمل وتعرض في ≤ 500ms
- البحث والتصفية فورية
- حذف المنتج يتطلب تأكيد ويحدث الحالة
- RTL صحيح للجدول والنصوص

---

## 3. إضافة منتج جديد (New Product)

**الغرض:** نموذج إنشاء منتج جديد مع جميع التفاصيل المطلوبة.

- **المسار:** `#/catalog-new`
- **المعالج:** `renderCatalogNew`
- **دعم RTL:** نموذج ومدخلات محاذاة لليمين

### المكونات والأحداث:
- **نموذج المنتج:**
  - الاسم: مطلوب، نص
  - الفئة: قائمة منسدلة مع الفئات المتاحة
  - السعر: مطلوب، رقم
  - المخزون: مطلوب، رقم صحيح
  - الوصف: نص طويل، rich text editor
  - المواصفات: مفاتيح/قيم قابلة للإضافة
  - الصور: رفع متعدد مع معاينة
- **أزرار العمل:**
  - حفظ: `onClick` → `actions.createProduct(productData)`
  - إلغاء: `onClick` → `navigate("#/catalog")`

### مفاتيح الترجمة:
```javascript
new_product: "منتج جديد",
product_details: "تفاصيل المنتج",
product_name: "اسم المنتج",
category: "الفئة",
price: "السعر",
stock_quantity: "كمية المخزون",
description: "الوصف",
specifications: "المواصفات",
images: "الصور",
upload_images: "رفع الصور",
save_product: "حفظ المنتج",
cancel: "إلغاء",
required_field: "حقل مطلوب",
invalid_price: "السعر غير صحيح",
invalid_stock: "كمية المخزون غير صحيحة"
```

### شرائح الحالة:
- `state.catalog.newProduct` (object)
- `state.catalog.categories` (array)
- `state.upload.images` (array)

### معايير القبول:
- التحقق من النموذج فوري مع رسائل خطأ واضحة
- رفع الصور مع معاينة فورية
- حفظ المنتج ينتقل لصفحة الكتالوج مع رسالة نجاح
- RTL صحيح لجميع عناصر النموذج

---

## 4. تحرير المنتج (Edit Product)

**الغرض:** تحرير منتج موجود مع إمكانية تحديث جميع التفاصيل.

- **المسار:** `#/catalog-edit/:id`
- **المعالج:** `renderCatalogEdit(id)`
- **دعم RTL:** نموذج ومدخلات محاذاة لليمين

### المكونات والأحداث:
- **نموذج محرر مملوء مسبقاً:**
  - نفس حقول إضافة منتج جديد مع البيانات الحالية
  - تحميل بيانات المنتج: `productById(id)`
- **أزرار العمل:**
  - تحديث: `onClick` → `actions.updateProduct(id, productData)`
  - حذف: `onClick` → `confirmDelete()` → `actions.deleteProduct(id)`
  - إلغاء: `onClick` → `navigate("#/catalog")`

### مفاتيح الترجمة:
```javascript
edit_product: "تحرير المنتج",
update_product: "تحديث المنتج",
delete_product: "حذف المنتج",
product_updated: "تم تحديث المنتج بنجاح",
update_failed: "فشل في تحديث المنتج",
loading_product: "جاري تحميل بيانات المنتج..."
```

### شرائح الحالة:
- `state.catalog.editingProduct` (object)
- `state.catalog.isLoading` (boolean)

### معايير القبول:
- تحميل بيانات المنتج في ≤ 300ms
- التحديث يحفظ التغييرات ويعرض رسالة نجاح
- الحذف يتطلب تأكيد مزدوج
- RTL صحيح للنموذج والرسائل

---

## 5. استيراد الكتالوج (Catalog Import)

**الغرض:** معالج استيراد CSV/Excel لإضافة منتجات بكميات كبيرة.

- **المسار:** `#/catalog-import`
- **المعالج:** `renderCatalogImport`
- **دعم RTL:** خطوات ونماذج محاذاة لليمين

### المكونات والأحداث:
- **خطوات الاستيراد:**
  1. رفع الملف: CSV/Excel file input
  2. مطابقة الأعمدة: map CSV columns to product fields
  3. معاينة: show first 5 rows with mapped data
  4. استيراد: process all rows with progress bar
- **التحقق:**
  - فحص صيغة الملف
  - التحقق من الأعمدة المطلوبة
  - معاينة الأخطاء قبل الاستيراد

### مفاتيح الترجمة:
```javascript
import_catalog: "استيراد الكتالوج",
upload_file: "رفع الملف",
file_format: "صيغة الملف",
csv_excel_only: "CSV أو Excel فقط",
column_mapping: "مطابقة الأعمدة",
preview_data: "معاينة البيانات",
import_products: "استيراد المنتجات",
import_progress: "تقدم الاستيراد",
import_complete: "اكتمل الاستيراد",
import_errors: "أخطاء الاستيراد",
invalid_file: "ملف غير صحيح",
missing_columns: "أعمدة مفقودة"
```

### شرائح الحالة:
- `state.import.file` (File object)
- `state.import.columns` (array)
- `state.import.mappings` (object)
- `state.import.progress` (number)

### معايير القبول:
- دعم ملفات CSV و Excel
- معاينة البيانات قبل الاستيراد النهائي
- شريط تقدم أثناء المعالجة
- تقرير بالأخطاء والنجاحات

---

## 6. إدارة الطلبات (Orders Management)

**الغرض:** عرض وإدارة جميع الطلبات مع تحديث الحالات.

- **المسار:** `#/orders`
- **المعالج:** `renderOrders`
- **دعم RTL:** جدول وقوائم محاذاة لليمين

### المكونات والأحداث:
- **جدول الطلبات:**
  - أعمدة: رقم الطلب، العميل، التاريخ، الحالة، المجموع، الإجراءات
  - حالات: جديد، قيد المعالجة، مشحون، مستلم، ملغي
  - تحديث الحالة: dropdown → `actions.updateOrderStatus(orderId, status)`
- **مرشحات:**
  - بحث برقم الطلب أو اسم العميل
  - تصفية بالحالة
  - تصفية بتاريخ النطاق

### مفاتيح الترجمة:
```javascript
orders: "الطلبات",
order_number: "رقم الطلب",
customer: "العميل",
date: "التاريخ",
status: "الحالة",
total: "المجموع",
new_order: "طلب جديد",
processing: "قيد المعالجة",
shipped: "مشحون",
delivered: "مستلم",
cancelled: "ملغي",
view_details: "عرض التفاصيل",
update_status: "تحديث الحالة",
search_orders: "بحث الطلبات"
```

### شرائح الحالة:
- `state.orders.list` (array)
- `state.orders.filters` (object)
- `state.orders.statusOptions` (array)

### معايير القبول:
- قائمة الطلبات تحمل وتعرض بسرعة
- تحديث الحالة فوري مع حفظ
- البحث والتصفية يعملان في الوقت الفعلي
- RTL صحيح للجدول والنصوص

---

## 7. تفاصيل الطلب (Order Details)

**الغرض:** عرض تفاصيل طلب محدد مع خيارات التحديث.

- **المسار:** `#/order/:id`
- **المعالج:** `renderOrderDetail(id)`
- **دعم RTL:** تفاصيل ونماذج محاذاة لليمين

### المكونات والأحداث:
- **معلومات الطلب:**
  - رقم الطلب، تاريخ الإنشاء، الحالة الحالية
  - معلومات العميل: الاسم، البريد، الهاتف
  - عنوان الشحن كاملاً
- **عناصر الطلب:**
  - قائمة المنتجات مع الصور، الأسماء، الكميات، الأسعار
  - إجمالي الطلب مع الشحن والضرائب
- **إجراءات الحالة:**
  - تحديث حالة الطلب مع ملاحظات
  - إضافة رقم التتبع للشحنات

### مفاتيح الترجمة:
```javascript
order_details: "تفاصيل الطلب",
order_info: "معلومات الطلب",
customer_info: "معلومات العميل",
shipping_address: "عنوان الشحن",
order_items: "عناصر الطلب",
tracking_number: "رقم التتبع",
add_tracking: "إضافة رقم التتبع",
order_notes: "ملاحظات الطلب",
subtotal: "الإجمالي الفرعي",
shipping_cost: "تكلفة الشحن",
tax: "الضريبة",
order_total: "إجمالي الطلب"
```

### شرائح الحالة:
- `state.orders.currentOrder` (object)
- `state.orders.isLoading` (boolean)

### معايير القبول:
- تحميل تفاصيل الطلب في ≤ 300ms
- تحديث الحالة يحفظ مع timestamp
- إضافة رقم التتبع يرسل إشعار للعميل
- RTL صحيح لجميع النصوص والتخطيط

---

## 8. إدارة المرتجعات (Returns Management)

**الغرض:** معالجة طلبات الإرجاع والاستبدال (RMA).

- **المسار:** `#/returns`
- **المعالج:** `renderReturns`
- **دعم RTL:** قائمة وتفاصيل محاذاة لليمين

### المكونات والأحداث:
- **قائمة طلبات الإرجاع:**
  - رقم RMA، رقم الطلب الأصلي، العميل، السبب، الحالة
  - حالات: مطلوب، معتمد، مرفوض، مستلم، مسترد
- **إجراءات الإرجاع:**
  - موافقة/رفض طلب الإرجاع
  - إنشاء تسمية شحن إرجاع
  - معالجة الاسترداد

### مفاتيح الترجمة:
```javascript
returns: "المرتجعات",
return_requests: "طلبات الإرجاع",
rma_number: "رقم RMA",
original_order: "الطلب الأصلي",
return_reason: "سبب الإرجاع",
return_status: "حالة الإرجاع",
requested: "مطلوب",
approved: "معتمد",
rejected: "مرفوض",
received: "مستلم",
refunded: "مسترد",
approve_return: "موافقة على الإرجاع",
reject_return: "رفض الإرجاع",
process_refund: "معالجة الاسترداد"
```

### شرائح الحالة:
- `state.returns.requests` (array)
- `state.returns.filters` (object)

### معايير القبول:
- قائمة طلبات الإرجاع محدثة
- موافقة/رفض مع إشعارات للعملاء
- تتبع حالة الاسترداد
- RTL صحيح للنصوص والحالات

---

## 9. أدوات المبدع (Creator Tools)

**الغرض:** أدوات لإنشاء المحتوى والتفاعل مع المتابعين.

- **المسار:** `#/creator`
- **المعالج:** `renderCreator`
- **دعم RTL:** محرر ومعاينة محاذاة لليمين

### المكونات والأحداث:
- **إنشاء المحتوى:**
  - رفع صور/فيديوهات للمنشورات
  - محرر نص للتعليقات
  - تعليم المنتجات في المنشورات
- **إحصائيات المبدع:**
  - عدد المتابعين، الإعجابات، التفاعل
  - أداء المنشورات الأخيرة
- **إدارة المحتوى:**
  - جدولة المنشورات
  - إدارة التعليقات والردود

### مفاتيح الترجمة:
```javascript
creator_tools: "أدوات المبدع",
create_post: "إنشاء منشور",
upload_media: "رفع وسائط",
post_caption: "تعليق المنشور",
tag_products: "تعليم المنتجات",
followers: "المتابعون",
engagement: "التفاعل",
post_performance: "أداء المنشورات",
schedule_post: "جدولة المنشور",
publish_now: "نشر الآن",
save_draft: "حفظ مسودة"
```

### شرائح الحالة:
- `state.creator.posts` (array)
- `state.creator.stats` (object)
- `state.creator.followers` (array)

### معايير القبول:
- رفع الوسائط سريع مع معاينة
- تعليم المنتجات سهل وبديهي
- إحصائيات محدثة في الوقت الفعلي
- RTL صحيح للمحرر والمعاينة

---

## 10. البث المباشر (Live Commerce)

**الغرض:** إعداد وإدارة جلسات البث المباشر للتجارة.

- **المسار:** `#/live`
- **المعالج:** `renderLive`
- **دعم RTL:** واجهة وعناصر تحكم محاذاة لليمين

### المكونات والأحداث:
- **إعداد البث:**
  - عنوان البث، وصف، صورة مصغرة
  - تحديد المنتجات المعروضة
  - إعدادات الكاميرا والصوت
- **واجهة البث المباشر:**
  - معاينة الفيديو
  - قائمة المنتجات الجانبية
  - تفاعل المشاهدين (تعليقات، أسئلة)
- **إحصائيات البث:**
  - عدد المشاهدين، التفاعل، المبيعات

### مفاتيح الترجمة:
```javascript
live_commerce: "التجارة المباشرة",
start_live_session: "بدء جلسة مباشرة",
live_title: "عنوان البث",
live_description: "وصف البث",
featured_products: "المنتجات المميزة",
camera_settings: "إعدادات الكاميرا",
audio_settings: "إعدادات الصوت",
viewers_count: "عدد المشاهدين",
live_comments: "تعليقات مباشرة",
end_session: "إنهاء الجلسة",
session_stats: "إحصائيات الجلسة"
```

### شرائح الحالة:
- `state.live.session` (object)
- `state.live.viewers` (array)
- `state.live.comments` (array)
- `state.live.products` (array)

### معايير القبول:
- إعداد البث سريع وسهل
- جودة فيديو وصوت ممتازة
- تفاعل المشاهدين في الوقت الفعلي
- RTL صحيح لجميع النصوص والواجهة

---

## 11. المحتوى المُولد من المستخدمين (UGC)

**الغرض:** إدارة المحتوى الذي ينشئه العملاء حول المنتجات.

- **المسار:** `#/ugc`
- **المعالج:** `renderUGC`
- **دعم RTL:** معرض ومرشحات محاذاة لليمين

### المكونات والأحداث:
- **معرض المحتوى:**
  - صور ومراجعات العملاء
  - تصفية بالمنتج أو التقييم
  - موافقة/رفض المحتوى للعرض
- **تشجيع المحتوى:**
  - حملات تحفيز العملاء لمشاركة تجاربهم
  - مسابقات ومكافآت للمحتوى الجيد

### مفاتيح الترجمة:
```javascript
user_generated_content: "المحتوى المُولد من المستخدمين",
customer_photos: "صور العملاء",
customer_reviews: "مراجعات العملاء",
approve_content: "موافقة على المحتوى",
reject_content: "رفض المحتوى",
feature_content: "إبراز المحتوى",
ugc_campaigns: "حملات المحتوى",
content_contests: "مسابقات المحتوى",
moderate_content: "إشراف على المحتوى"
```

### شرائح الحالة:
- `state.ugc.content` (array)
- `state.ugc.pending` (array)
- `state.ugc.campaigns` (array)

### معايير القبول:
- إشراف سريع على المحتوى
- تشجيع فعال للعملاء على المشاركة
- عرض جذاب للمحتوى المعتمد
- RTL صحيح للنصوص والواجهة

---

## 12. التحليلات (Analytics)

**الغرض:** مخططات وتقارير مفصلة عن الأداء مع إمكانية التصفية بالتاريخ.

- **المسار:** `#/analytics`
- **المعالج:** `renderAnalytics`
- **دعم RTL:** مخططات وتقارير محاذاة لليمين

### المكونات والأحداث:
- **مخططات الأداء:**
  - مبيعات بالوقت: line chart
  - أفضل المنتجات: bar chart
  - مصادر الزيارات: pie chart
  - معدلات التحويل: area chart
- **مرشحات التاريخ:**
  - آخر 7 أيام، 30 يوم، 3 أشهر، سنة
  - نطاق تاريخ مخصص
- **تقارير قابلة للتصدير:**
  - CSV, PDF downloads
  - تقارير مجدولة عبر البريد الإلكتروني

### مفاتيح الترجمة:
```javascript
analytics: "التحليلات",
sales_analytics: "تحليلات المبيعات",
performance_metrics: "مقاييس الأداء",
time_period: "الفترة الزمنية",
last_7_days: "آخر 7 أيام",
last_30_days: "آخر 30 يوم",
last_3_months: "آخر 3 أشهر",
custom_range: "نطاق مخصص",
export_report: "تصدير التقرير",
scheduled_reports: "التقارير المجدولة",
traffic_sources: "مصادر الزيارات",
conversion_funnel: "قمع التحويل"
```

### شرائح الحالة:
- `state.analytics.sales` (array)
- `state.analytics.traffic` (object)
- `state.analytics.conversions` (object)
- `state.analytics.dateRange` (object)

### معايير القبول:
- المخططات تحمل وتعرض بسرعة
- التصفية بالتاريخ فورية
- تصدير التقارير يعمل بصيغ متعددة
- RTL صحيح للمخططات والنصوص

---

## 13. الإعدادات (Settings)

**الغرض:** إدارة ملف المتجر والتفضيلات.

- **المسار:** `#/settings`
- **المعالج:** `renderSettings`
- **دعم RTL:** نماذج وتحكم محاذاة لليمين

### المكونات والأحداث:
- **ملف المتجر:**
  - اسم المتجر، الشعار، البريد الإلكتروني للتواصل
  - وصف المتجر، ساعات العمل
- **تفضيلات النظام:**
  - إعدادات الإشعارات
  - تفضيلات اللغة والمنطقة الزمنية
  - إعدادات الخصوصية

### مفاتيح الترجمة:
```javascript
settings: "الإعدادات",
store_profile: "ملف المتجر",
store_name: "اسم المتجر",
store_logo: "شعار المتجر",
contact_email: "بريد التواصل",
store_description: "وصف المتجر",
business_hours: "ساعات العمل",
notifications: "الإشعارات",
privacy_settings: "إعدادات الخصوصية",
save_settings: "حفظ الإعدادات",
settings_saved: "تم حفظ الإعدادات بنجاح"
```

### شرائح الحالة:
- `state.seller.profile` (object)
- `state.seller.preferences` (object)

### معايير القبول:
- حفظ الإعدادات فوري مع تأكيد
- رفع الشعار مع معاينة
- تطبيق التفضيلات على الواجهة
- RTL صحيح لجميع النماذج

---

## 14. الفوترة (Billing)

**الغرض:** إدارة الاشتراك والفواتير.

- **المسار:** `#/billing`
- **المعالج:** `renderBilling`
- **دعم RTL:** فواتير وجداول محاذاة لليمين

### المكونات والأحداث:
- **حالة الاشتراك:**
  - الخطة الحالية، تاريخ التجديد، المبلغ
  - خيارات ترقية/تخفيض الخطة
- **تاريخ الفواتير:**
  - قائمة الفواتير السابقة مع إمكانية التحميل
  - حالة الدفع: مدفوع، معلق، متأخر
- **طرق الدفع:**
  - إدارة البطاقات المحفوظة
  - إضافة طريقة دفع جديدة

### مفاتيح الترجمة:
```javascript
billing: "الفوترة",
subscription: "الاشتراك",
current_plan: "الخطة الحالية",
renewal_date: "تاريخ التجديد",
upgrade_plan: "ترقية الخطة",
downgrade_plan: "تخفيض الخطة",
billing_history: "تاريخ الفوترة",
invoice_number: "رقم الفاتورة",
payment_status: "حالة الدفع",
paid: "مدفوع",
pending: "معلق",
overdue: "متأخر",
payment_methods: "طرق الدفع",
add_payment_method: "إضافة طريقة دفع",
download_invoice: "تحميل الفاتورة"
```

### شرائح الحالة:
- `state.billing.subscription` (object)
- `state.billing.invoices` (array)
- `state.billing.paymentMethods` (array)

### معايير القبول:
- عرض حالة الاشتراك الحالية بوضوح
- تحميل الفواتير بصيغة PDF
- إدارة طرق الدفع آمنة
- RTL صحيح للأرقام والنصوص المالية
