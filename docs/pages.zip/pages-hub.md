# صفحة المحور (Hub Page)

**لغة الموقع الأساسية:** العربية السعودية مع دعم RTL - Arabic Saudi dialect with RTL support

يربط هذا المستند صفحة المحور بوظائفها ويوفر ملاحظات التنفيذ للمطورين.

الملف: `index.html`

---

## نظرة عامة على المحور (Hub Overview)

**الغرض:** نقطة دخول موحدة لاختيار الشخصية والوصول إلى التطبيقات المختلفة في النظام البيئي StoreZ.

- **المسار:** `/index.html` (الصفحة الرئيسية)
- **الوظيفة:** صفحة ثابتة مع JavaScript مدمج
- **دعم RTL:** واجهة كاملة محاذاة لليمين

---

## المكونات والوظائف

### 1. رأس الصفحة (Header Section)
- **شعار StoreZ:** صورة مع نص العلامة التجارية
- **شعار النبذة:** "منصة التجارة الاجتماعية الرائدة في المملكة"
- **مبدل اللغة:** زر تبديل بين العربية والإنجليزية
- **مبدل السمة:** زر تبديل بين السمة الفاتحة والداكنة

### 2. اختيار الشخصية (Persona Selection)
- **بطاقة المشتري:**
  - الأيقونة: أيقونة عربة التسوق
  - العنوان: "أريد التسوق" / "I want to shop"
  - الوصف: "تصفح واشتر من آلاف المنتجات"
  - الزر: "دخول كمشتري" → `openApp('buyer')`
- **بطاقة البائع:**
  - الأيقونة: أيقونة المتجر
  - العنوان: "أريد البيع" / "I want to sell"
  - الوصف: "أنشئ متجرك وابدأ البيع اليوم"
  - الزر: "دخول كبائع" → `openApp('seller')`
- **بطاقة المدير:**
  - الأيقونة: أيقونة الإعدادات
  - العنوان: "إدارة المنصة" / "Manage platform"
  - الوصف: "لوحة تحكم شاملة للمديرين"
  - الزر: "دخول كمدير" → `openApp('admin')`

### 3. القسم المعلوماتي (Info Section)
- **إحصائيات المنصة:**
  - عدد المستخدمين المسجلين
  - عدد البائعين النشطين
  - عدد المنتجات المتاحة
  - حجم المبيعات الإجمالي
- **الميزات الرئيسية:**
  - "البث المباشر" - جلسات تسوق تفاعلية
  - "المحتوى الاجتماعي" - مراجعات وصور العملاء
  - "الدفع الآمن" - حماية كاملة للمعاملات
  - "الشحن السريع" - توصيل في نفس اليوم

### 4. ذيل الصفحة (Footer Section)
- **روابط سريعة:**
  - حول StoreZ
  - شروط الخدمة
  - سياسة الخصوصية
  - اتصل بنا
- **وسائل التواصل الاجتماعي:**
  - تويتر، انستغرام، سناب شات، لينكد إن
- **معلومات الاتصال:**
  - البريد الإلكتروني: info@storez.sa
  - الهاتف: +966 11 123 4567
  - العنوان: الرياض، المملكة العربية السعودية

---

## الوظائف والأحداث

### `openApp(appType)` وظيفة فتح التطبيق
```javascript
function openApp(appType) {
    // تحديد المسار بناءً على نوع التطبيق
    const appPaths = {
        'buyer': './frontend/buyer/',
        'seller': './frontend/Seller/',
        'admin': './frontend/admin/'
    };
    
    // حفظ آخر شخصية مستخدمة
    localStorage.setItem('storez_persona', appType);
    
    // فتح التطبيق في نافذة جديدة
    const newWindow = window.open(
        appPaths[appType], 
        appType + '_app',
        'width=1200,height=800,scrollbars=yes,resizable=yes'
    );
    
    // التركيز على النافذة الجديدة
    if (newWindow) {
        newWindow.focus();
    }
}
```

### `toggleLanguage()` تبديل اللغة
```javascript
function toggleLanguage() {
    const currentLang = localStorage.getItem('storez_language') || 'ar';
    const newLang = currentLang === 'ar' ? 'en' : 'ar';
    localStorage.setItem('storez_language', newLang);
    updatePageLanguage(newLang);
}
```

### `toggleTheme()` تبديل السمة
```javascript
function toggleTheme() {
    const currentTheme = localStorage.getItem('storez_theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    localStorage.setItem('storez_theme', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
}
```

### `loadPlatformStats()` تحميل إحصائيات المنصة
```javascript
function loadPlatformStats() {
    // محاكاة تحميل الإحصائيات من API
    const stats = {
        users: 150000,
        sellers: 5000,
        products: 75000,
        sales: '2.5M SAR'
    };
    updateStatsDisplay(stats);
}
```

### `autoRedirectToLastPersona()` إعادة التوجيه التلقائي
```javascript
function autoRedirectToLastPersona() {
    const lastPersona = localStorage.getItem('storez_persona');
    const autoRedirect = localStorage.getItem('storez_auto_redirect') === 'true';
    
    if (autoRedirect && lastPersona) {
        // عرض رسالة توضيحية لمدة 3 ثوان قبل إعادة التوجيه
        showAutoRedirectMessage(lastPersona);
        setTimeout(() => {
            openApp(lastPersona);
        }, 3000);
    }
}
```

---

## مفاتيح الترجمة (i18n Keys)

### النصوص الأساسية
```javascript
const translations = {
    ar: {
        // رأس الصفحة
        platform_tagline: "منصة التجارة الاجتماعية الرائدة في المملكة",
        language_toggle: "English",
        theme_toggle: "السمة الداكنة",
        
        // اختيار الشخصية
        persona_selection: "اختر كيف تريد البدء",
        buyer_title: "أريد التسوق",
        buyer_description: "تصفح واشتر من آلاف المنتجات من البائعين المعتمدين",
        buyer_button: "دخول كمشتري",
        seller_title: "أريد البيع",
        seller_description: "أنشئ متجرك الإلكتروني وابدأ البيع للعملاء في جميع أنحاء المملكة",
        seller_button: "دخول كبائع",
        admin_title: "إدارة المنصة",
        admin_description: "لوحة تحكم شاملة لإدارة المستخدمين والمحتوى والعمليات",
        admin_button: "دخول كمدير",
        
        // إعادة التوجيه التلقائي
        auto_redirect_title: "إعادة توجيه تلقائي",
        auto_redirect_message: "سيتم توجيهك تلقائياً إلى",
        auto_redirect_cancel: "إلغاء",
        auto_redirect_setting: "التوجيه التلقائي للشخصية الأخيرة",
        
        // الإحصائيات
        platform_stats: "إحصائيات المنصة",
        registered_users: "مستخدم مسجل",
        active_sellers: "بائع نشط",
        available_products: "منتج متاح",
        total_sales: "إجمالي المبيعات",
        
        // الميزات
        key_features: "الميزات الرئيسية",
        live_streaming: "البث المباشر",
        live_streaming_desc: "جلسات تسوق تفاعلية مع البائعين",
        social_content: "المحتوى الاجتماعي",
        social_content_desc: "مراجعات وصور حقيقية من العملاء",
        secure_payment: "الدفع الآمن",
        secure_payment_desc: "حماية كاملة لجميع المعاملات المالية",
        fast_shipping: "الشحن السريع",
        fast_shipping_desc: "توصيل في نفس اليوم داخل المدن الرئيسية",
        
        // ذيل الصفحة
        quick_links: "روابط سريعة",
        about_storez: "حول StoreZ",
        terms_service: "شروط الخدمة",
        privacy_policy: "سياسة الخصوصية",
        contact_us: "اتصل بنا",
        social_media: "تابعنا على",
        contact_info: "معلومات الاتصال",
        email_label: "البريد الإلكتروني:",
        phone_label: "الهاتف:",
        address_label: "العنوان:",
        riyadh_address: "الرياض، المملكة العربية السعودية"
    },
    en: {
        // Header
        platform_tagline: "Leading Social Commerce Platform in Saudi Arabia",
        language_toggle: "العربية",
        theme_toggle: "Dark Theme",
        
        // Persona Selection
        persona_selection: "Choose how you want to get started",
        buyer_title: "I want to shop",
        buyer_description: "Browse and buy from thousands of products from verified sellers",
        buyer_button: "Enter as Buyer",
        seller_title: "I want to sell",
        seller_description: "Create your online store and start selling to customers across the Kingdom",
        seller_button: "Enter as Seller",
        admin_title: "Manage Platform",
        admin_description: "Comprehensive dashboard to manage users, content, and operations",
        admin_button: "Enter as Admin",
        
        // Auto Redirect
        auto_redirect_title: "Auto Redirect",
        auto_redirect_message: "You will be automatically redirected to",
        auto_redirect_cancel: "Cancel",
        auto_redirect_setting: "Auto-redirect to last persona",
        
        // Statistics
        platform_stats: "Platform Statistics",
        registered_users: "Registered Users",
        active_sellers: "Active Sellers",
        available_products: "Available Products",
        total_sales: "Total Sales",
        
        // Features
        key_features: "Key Features",
        live_streaming: "Live Streaming",
        live_streaming_desc: "Interactive shopping sessions with sellers",
        social_content: "Social Content",
        social_content_desc: "Real reviews and photos from customers",
        secure_payment: "Secure Payment",
        secure_payment_desc: "Complete protection for all financial transactions",
        fast_shipping: "Fast Shipping",
        fast_shipping_desc: "Same-day delivery in major cities",
        
        // Footer
        quick_links: "Quick Links",
        about_storez: "About StoreZ",
        terms_service: "Terms of Service",
        privacy_policy: "Privacy Policy",
        contact_us: "Contact Us",
        social_media: "Follow Us",
        contact_info: "Contact Information",
        email_label: "Email:",
        phone_label: "Phone:",
        address_label: "Address:",
        riyadh_address: "Riyadh, Saudi Arabia"
    }
};
```

---

## دعم RTL (Right-to-Left Support)

### CSS للدعم الكامل لـ RTL
```css
/* دعم الاتجاه حسب اللغة */
html[lang="ar"] {
    direction: rtl;
    text-align: right;
    font-family: 'IBM Plex Sans Arabic', 'Tahoma', sans-serif;
}

html[lang="en"] {
    direction: ltr;
    text-align: left;
    font-family: 'Inter', 'Segoe UI', sans-serif;
}

/* تخطيط البطاقات مع RTL */
.persona-cards {
    display: flex;
    flex-direction: row;
    gap: 2rem;
    justify-content: center;
    flex-wrap: wrap;
}

html[lang="ar"] .persona-cards {
    flex-direction: row-reverse;
}

/* أزرار مع دعم RTL */
.btn {
    padding: 12px 24px;
    border-radius: 8px;
    transition: all 0.3s ease;
    cursor: pointer;
    border: none;
    font-weight: 600;
}

html[lang="ar"] .btn {
    font-family: 'IBM Plex Sans Arabic', sans-serif;
}

html[lang="en"] .btn {
    font-family: 'Inter', sans-serif;
}

/* الأيقونات مع RTL */
html[lang="ar"] .icon-with-text {
    flex-direction: row-reverse;
}

html[lang="ar"] .icon-with-text .icon {
    margin-left: 8px;
    margin-right: 0;
}

/* إحصائيات المنصة مع RTL */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin: 2rem 0;
}

html[lang="ar"] .stat-number {
    font-family: 'IBM Plex Sans Arabic', sans-serif;
    direction: ltr;
    text-align: center;
}

/* رسالة إعادة التوجيه التلقائي */
.auto-redirect-modal {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.15);
    z-index: 1000;
    text-align: center;
    min-width: 300px;
}

html[lang="ar"] .auto-redirect-modal {
    direction: rtl;
    text-align: right;
}
```

---

## حالة التطبيق (Application State)

### LocalStorage Keys
- `storez_language`: 'ar' أو 'en'
- `storez_theme`: 'light' أو 'dark'
- `storez_persona`: 'buyer', 'seller', أو 'admin' (آخر شخصية مستخدمة)
- `storez_auto_redirect`: 'true' أو 'false' (إعداد إعادة التوجيه التلقائي)
- `storez_hub_visits`: عدد الزيارات للمحور
- `storez_last_visit`: timestamp لآخر زيارة

### State Object
```javascript
const hubState = {
    language: 'ar',
    theme: 'light',
    lastPersona: null,
    autoRedirect: false,
    stats: {
        users: 0,
        sellers: 0,
        products: 0,
        sales: '0 SAR'
    },
    isLoading: false,
    lastUpdated: null,
    visitCount: 0
};
```

### Event Handlers
```javascript
// معالج أحداث النقر على بطاقات الشخصية
function handlePersonaClick(event) {
    const personaType = event.currentTarget.dataset.persona;
    const timestamp = new Date().toISOString();
    
    // تسجيل الحدث
    console.log(`User selected persona: ${personaType} at ${timestamp}`);
    
    // فتح التطبيق
    openApp(personaType);
}

// معالج تغيير إعدادات إعادة التوجيه التلقائي
function handleAutoRedirectToggle(event) {
    const enabled = event.target.checked;
    localStorage.setItem('storez_auto_redirect', enabled.toString());
    
    if (!enabled) {
        localStorage.removeItem('storez_persona');
    }
}

// معالج أحداث لوحة المفاتيح للوصولية
function handleKeyboardNavigation(event) {
    const focusableElements = document.querySelectorAll('.persona-card, .lang-toggle, .theme-toggle');
    const currentIndex = Array.from(focusableElements).indexOf(event.target);
    
    switch(event.key) {
        case 'ArrowRight':
            event.preventDefault();
            const nextIndex = (currentIndex + 1) % focusableElements.length;
            focusableElements[nextIndex].focus();
            break;
        case 'ArrowLeft':
            event.preventDefault();
            const prevIndex = (currentIndex - 1 + focusableElements.length) % focusableElements.length;
            focusableElements[prevIndex].focus();
            break;
        case 'Enter':
        case ' ':
            event.preventDefault();
            event.target.click();
            break;
    }
}
```

---

## معايير القبول (Acceptance Criteria)

### الوظائف الأساسية
- ✅ تحميل الصفحة في أقل من 2 ثانية
- ✅ فتح التطبيقات في نوافذ جديدة بنجاح
- ✅ تبديل اللغة فوري مع حفظ التفضيل
- ✅ تبديل السمة يطبق على كامل الصفحة
- ✅ عرض إحصائيات محدثة للمنصة
- ✅ حفظ واسترداد آخر شخصية مستخدمة
- ✅ إعادة التوجيه التلقائي (اختياري) مع إمكانية الإلغاء

### تجربة المستخدم
- ✅ واجهة مستجيبة على جميع الأجهزة (320px - 2560px)
- ✅ انتقالات سلسة بين العناصر (300ms transition)
- ✅ أزرار واضحة ومفهومة مع hover effects
- ✅ تحميل سريع للصور والأيقونات (≤ 1 ثانية)
- ✅ رسائل خطأ واضحة في حالة فشل فتح التطبيقات
- ✅ إمكانية الوصول عبر لوحة المفاتيح
- ✅ دعم قارئات الشاشة مع ARIA labels

### دعم RTL والترجمة
- ✅ محاذاة صحيحة لجميع العناصر في الوضع العربي
- ✅ خطوط عربية واضحة ومقروءة (IBM Plex Sans Arabic)
- ✅ ترجمة كاملة لجميع النصوص والرسائل
- ✅ أرقام عربية هندية للإحصائيات في الوضع العربي
- ✅ تخطيط مرآة كامل للواجهة (flex-direction: row-reverse)
- ✅ اتجاه صحيح للأيقونات والرموز
- ✅ دعم تبديل اللغة مع الحفاظ على السياق

### الأداء والموثوقية
- ✅ تحميل الإحصائيات مع fallback للبيانات المحلية
- ✅ معالجة أخطاء فتح النوافذ الجديدة مع popup blockers
- ✅ حفظ تفضيلات المستخدم بشكل موثوق
- ✅ دعم المتصفحات الحديثة (Chrome 90+, Safari 14+, Firefox 88+, Edge 90+)
- ✅ أداء ممتاز على الأجهزة المحمولة (LCP ≤ 2.5s)
- ✅ تخزين محلي مع حد أقصى 5MB
- ✅ graceful degradation للمتصفحات القديمة

### الأمان والخصوصية
- ✅ عدم تخزين بيانات حساسة في localStorage
- ✅ التحقق من صحة المدخلات قبل التخزين
- ✅ حماية من XSS في عرض المحتوى الديناميكي
- ✅ HTTPS إجباري للنسخة الإنتاجية
- ✅ سياسات CSP مناسبة للأمان
- ✅ تشفير البيانات الحساسة قبل التخزين المحلي

### إمكانية الوصول (Accessibility)
- ✅ دعم كامل لقارئات الشاشة
- ✅ تنقل بلوحة المفاتيح لجميع العناصر التفاعلية
- ✅ نسبة تباين ألوان مناسبة (4.5:1 minimum)
- ✅ أحجام خط مناسبة (16px minimum)
- ✅ focus indicators واضحة
- ✅ alt text للصور والأيقونات
- ✅ ARIA labels للعناصر المعقدة
